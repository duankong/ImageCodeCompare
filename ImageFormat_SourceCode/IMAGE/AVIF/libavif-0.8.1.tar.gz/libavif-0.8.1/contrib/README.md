# libavif external contributions

Anything in this directory was contributed by an external author and is not officially maintained by
libavif directly, nor are there any expectations of continued functionality. Any CMake options
offered in libavif's CMakeLists that cite files in this subdirectory are guaranteed to be disabled
by default.

See libavif's `LICENSE` file to learn about any additional license requirements/information for any
subdirectories in here.
