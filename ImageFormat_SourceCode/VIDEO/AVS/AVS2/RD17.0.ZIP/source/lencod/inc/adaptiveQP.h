#ifndef __ADAPTIVEQP__
#define __ADAPTIVEQP__

#include "global.h"

void adaptiveQPInit(int iWidth, int iHeight, unsigned int uiMaxAQDepth);
void xPreanalyze(int iWidth, int iHeight);


#endif // __adaptiveQP__
