

// Do nothing here
// It is to be replaced by HW version of the same file
//
//

#define KERNEL(x) x


