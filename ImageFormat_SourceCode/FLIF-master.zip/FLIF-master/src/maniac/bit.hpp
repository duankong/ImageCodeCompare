#pragma once
#ifdef _MSC_VER

int __builtin_clz(unsigned int value);

#endif