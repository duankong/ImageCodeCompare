#pragma once

#include "flif-interface-private_enc.hpp"
#include "flif-interface-private_dec.hpp"
