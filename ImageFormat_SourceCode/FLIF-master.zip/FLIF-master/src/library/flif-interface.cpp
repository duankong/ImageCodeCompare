#include "flif-interface_dec.cpp"
#ifdef HAS_ENCODER
#include "flif-interface_enc.cpp"
#endif
