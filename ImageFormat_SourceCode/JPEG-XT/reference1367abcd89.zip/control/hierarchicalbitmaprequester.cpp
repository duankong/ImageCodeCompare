/*************************************************************************
** Written by Thomas Richter (THOR Software - thor@math.tu-berlin.de)   **
** Sponsored by Accusoft Corporation, Tampa, FL and                     **
** the Computing Center of the University of Stuttgart                  **
**************************************************************************

The copyright in this software is being made available under the
license included below. This software may be subject to other third
party and contributor rights, including patent rights, and no such
rights are granted under this license.
 
Copyright (c) 2013-2017, ISO
All rights reserved.

This software module was originally contributed by the parties as
listed below in the course of development of the ISO/IEC 18477 (JPEG
XT) standard for validation and reference purposes:

- University of Stuttgart
- Accusoft

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:
  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
  * Neither the name of the University of Stuttgart or Accusoft nor
    the names of its contributors may be used to endorse or promote
    products derived from this software without specific prior written
    permission.
  * Redistributed products derived from this software must conform to
    ISO/IEC 18477 (JPEG XT) except that non-commercial redistribution
    for research and for furtherance of ISO/IEC standards is permitted.
    Otherwise, contact the contributing parties for any other
    redistribution rights for products derived from this software.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*************************************************************************/
/*
**
** This is the top-level bitmap requester that distributes data to
** image scales on encoding, and collects data from image scales on
** decoding. It also keeps the top-level color transformer and the
** toplevel subsampling expander.
**
** $Id: hierarchicalbitmaprequester.cpp,v 1.37 2016/10/28 13:58:53 thor Exp $
**
*/

/// Includes
#include "control/hierarchicalbitmaprequester.hpp"
#include "control/lineadapter.hpp"
#include "control/linemerger.hpp"
#include "std/string.hpp"
#include "upsampling/downsamplerbase.hpp"
#include "upsampling/upsamplerbase.hpp"
#include "marker/frame.hpp"
#include "marker/component.hpp"
#include "colortrafo/colortrafo.hpp"
#include "codestream/rectanglerequest.hpp"
#include "codestream/tables.hpp"
///

/// HierarchicalBitmapRequester::HierarchicalBitmapRequester
// Construct from a frame - the frame is just a "dummy frame"
// that contains the dimensions, actually a DHP marker segment
// without any data in it.
HierarchicalBitmapRequester::HierarchicalBitmapRequester(class Frame *dimensions)
  : BitmapCtrl(dimensions)
{
}
///

/// HierarchicalBitmapRequester::~HierarchicalBitmapRequester
HierarchicalBitmapRequester::~HierarchicalBitmapRequester(void)
{
}
///

/// HierarchicalBitmapRequester::BuildCommon
// Build common structures for encoding and decoding
///

/// HierarchicalBitmapRequester::PrepareForEncoding
// First time usage: Collect all the information for encoding.
// May throw on out of memory situations
void HierarchicalBitmapRequester::PrepareForEncoding(void)
{
}
///

/// HierarchicalBitmapRequester::PrepareForDecoding
// First time usage: Collect all the information for encoding.
// May throw on out of memory situations
void HierarchicalBitmapRequester::PrepareForDecoding(void)
{
}
///

/// HierarchicalBitmapRequester::ColorTrafoOf
// Return the color transformer responsible for this scan.
class ColorTrafo *HierarchicalBitmapRequester::ColorTrafoOf(bool encoding)
{
  return m_pFrame->TablesOf()->ColorTrafoOf(m_pFrame,NULL,PixelTypeOf(),encoding);
}
///

/// HierarchicalBitmapRequester::AddImageScale
// As soon as a frame is parsed off, or created: Add another scale to the image.
// The boolean arguments identify whether the reference frame, i.e. what is
// buffered already from previous frames, will be expanded.
void HierarchicalBitmapRequester::AddImageScale(class Frame *frame,bool expandh,bool expandv)
{
  NOREF(frame);
  NOREF(expandh);
  NOREF(expandv);
}
///

/// HierarchicalBitmapRequester::GenerateDifferentialImage
// After having written the previous image, compute the differential from the downscaled
// and-re-upscaled version and push it into the next frame, collect the
// residuals, make this frame ready for encoding, and retrieve the downscaling
// data.
void HierarchicalBitmapRequester::GenerateDifferentialImage(class Frame *target,
                                                            bool &hexp,bool &vexp)
{
  NOREF(target);
  NOREF(hexp);
  NOREF(vexp);
  JPG_THROW(NOT_IMPLEMENTED,"HierarchicalBitmapRequester::GenerateDifferentialImage",
            "Lossless JPEG not available in your code release, please contact Accusoft for a full version");
}
///

/// HierarchicalBitmapRequester::DefineRegion
// Define a single 8x8 block starting at the x offset and the given
// line, taking the input 8x8 buffer.
///

/// HierarchicalBitmapRequester::FetchRegion
// Define a single 8x8 block starting at the x offset and the given
// line, taking the input 8x8 buffer.
///

/// HierarchicalBitmapRequester::Allocate8Lines
// Get the next block of eight lines of the image
///

/// HierarchicalBitmapRequester::Push8Lines
// Advance the image line pointer by the next eight lines
// which is here a "pseudo"-MCU block.
///

/// HierarchicalBitmapRequester::Pull8Lines
// Pull 8 lines from the top-level and place them into
// the decoder MCU.
///

/// HierarchicalBitmapRequester::Release8Lines
// Release the currently buffered decoder MCU for the given component.
///

/// HierarchicalBitmapRequester::CropEncodingRegion
// First step of a region encoder: Find the region that can be pulled in the next step,
// from a rectangle request. This potentially shrinks the rectangle, which should be
// initialized to the full image.
void HierarchicalBitmapRequester::CropEncodingRegion(RectAngle<LONG> &region,const struct RectangleRequest *)
{ 
  NOREF(region);
}
///

/// HierarchicalBitmapRequester::RequestUserDataForEncoding
// Request user data for encoding for the given region, potentially clip the region to the
// data available from the user.
void HierarchicalBitmapRequester::RequestUserDataForEncoding(class BitMapHook *bmh,RectAngle<LONG> &region,bool alpha)
{
  NOREF(bmh);
  NOREF(region);
  NOREF(alpha);
}
///

/// HierarchicalBitmapRequester::RequestUserDataForDecoding
// Pull data buffers from the user data bitmap hook
void HierarchicalBitmapRequester::RequestUserDataForDecoding(class BitMapHook *bmh,RectAngle<LONG> &region,
                                                             const struct RectangleRequest *rr,bool alpha)
{
  NOREF(bmh);
  NOREF(region);
  NOREF(rr);
  NOREF(alpha);
}
///

/// HierarchicalBitmapRequester::EncodeRegion
// Encode a region without downsampling but color transformation
void HierarchicalBitmapRequester::EncodeRegion(const RectAngle<LONG> &region)
{
  NOREF(region);
}
///

/// HierarchicalBitmapRequester::ReconstructRegion
// Reconstruct a block, or part of a block
void HierarchicalBitmapRequester::ReconstructRegion(const RectAngle<LONG> &region,const struct RectangleRequest *rr)
{
  NOREF(region);
  NOREF(rr);
}
///

/// HierarchicalBitmapRequester::isNextMCULineReady
// Return true if the next MCU line is buffered and can be pushed
// to the encoder.
bool HierarchicalBitmapRequester::isNextMCULineReady(void) const
{
  return false;
}
///

/// HierarchicalBitmapRequester::ResetToStartOfImage
// Reset all components on the image side of the control to the
// start of the image. Required when re-requesting the image
// for encoding or decoding.
void HierarchicalBitmapRequester::ResetToStartOfImage(void)
{
}
///

/// HierarchicalBitmapRequester::isImageComplete
// Return an indicator whether all of the image has been loaded into
// the image buffer.
bool HierarchicalBitmapRequester::isImageComplete(void) const
{ 
  return false;
}
///

/// HierarchicalBitmapRequester::BufferedLines
// Return the number of lines available for reconstruction from this scan.
ULONG HierarchicalBitmapRequester::BufferedLines(const struct RectangleRequest *rr) const
{
  NOREF(rr);
  return 0;
}
///

/// HierarchicalBitmapRequester::PostImageHeight
// Post the height of the frame in lines. This happens
// when the DNL marker is processed.
void HierarchicalBitmapRequester::PostImageHeight(ULONG lines)
{
  BitmapCtrl::PostImageHeight(lines);
}
///
